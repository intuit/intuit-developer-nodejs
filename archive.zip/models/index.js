// export everything in the models directory
// add other files you create here and require just this file

/**
 * load just this file to get all the models in your code
 * @type {exports|module.exports}
 */
exports.quickbooksModel = require('./quickbooks_model');
exports.quickbaseModel  = require('./quickbase_model');

