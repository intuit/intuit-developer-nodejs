CANCAN V2
========

Version of the QBO France migration code updated to new version of express, and using express-generator.

Setup
=====
- download and run mongodb. Note its port number (27017 by default)
- run 'npm install' to install the packages in package.json
- set NODE_ENV=development
- create a file named properties in the root directory. Add the following information to it, in the format shown
* quickbase-apptoken = _an apptoken from the 'Settings' section of the quickbase_
* quickbase-username =  _username_
* quickbase-password =  _password_
* consumerKey    =  _your_consumer_key_from_developer.intuit.com_
* consumerSecret = _your_consumer_secret_from_developer.intuit.com_




USAGE
=====
start mongod. you may need to provide it a data directory (suggested: ../data)
use nodemon to run. (nodemon bin/www). 
After starting. navigate to localhost:3000/quickbooks/start to start the oath process with QB.

TESTING
=======
A basic set of tests is available - run 'mocha' from the root directory. Note that the tests do not cover openid/oauth at this time. The framework expects that this is done by the user by going to localhost:3000 and logging in



