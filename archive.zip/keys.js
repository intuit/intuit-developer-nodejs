/**
 * Created by sram on 7/6/15.
 */
var config = {};

// DEPRECATED. DO NOT USE> CREATE A LOCAL PROPERTIES FILE

module.exports = config;