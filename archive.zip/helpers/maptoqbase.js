

/**
 * Maps data from QBO to quickbase
 * @type {*|exports|module.exports}
 */


/**
 * Takes a QBO account object, maps and stores it in QuickBase
 * @param account
 */
function accountMapper(account) {

}


module.exports.accountMapper = accountMapper;